#include <iostream>
#include <ctime>
#include <stdlib.h>
using namespace std;
int main()
{
    cout << "-------------------------------------------------------------------------------------\n";
    cout << "a program that will help an elementary school student learn multiplication\n";
    cout << "-------------------------------------------------------------------------------------\n";
    int multiple = 0;
    int answer = 0;
    cout << "Enter -1 to End.";
    cin >> multiple;
    while (multiple != -1)
    {
        srand(time(0));
        int n1 = rand() % 10;
        int n2 = rand() % 10;

        cout << "How much is " << n1 << " times " << n2;
        cout << " (-1 to End)? ";
        answer = n1 * n2;
        cout << endl;
        cin >> multiple;

        if (multiple != -1)
        {
            if (answer == multiple)
            {
                cout << "Very good!";
            }
            else
            {
                while (answer != multiple)
                {
                    cout << " No. Please try again.";
                    cin >> multiple;
                }
                cout << "Very good!";
            }
            cout << endl;
        }
        else
        {
            break;
        }
    }
    cout << "That's all for now. Bye.";
    return 0;
}