#include <iostream>
using namespace std;

void input(float &height, float &weight);
int calculating(float height, float weight);
void output(int returnValue);
int main()
{
    cout << "----------------------------------------------------------------------------------\n";
    cout << " underweight, normal, or overweight,\n";
    cout << "----------------------------------------------------------------------------------\n";
    float height = 0;
    float weight = 0;
    input(height, weight);

    calculating(height, weight);
    int returnValue = calculating(height, weight);
    output(returnValue);
    return 0;
}
void input(float &height, float &weight)
{

    cout << " height(cm) : ";
    cin >> height;
    cout << " weight(kg) : ";
    cin >> weight;
}
int calculating(float height, float weight)
{
    if (weight < height / 2.50)
        return 1;
    else if (height / 2.5 <= weight <= height / 2.3)
        return 2;
    else
        return 3;
}
void output(int returnValue)
{
    if (returnValue == 1)
    {
        cout << "Underweight";
    }
    else if (returnValue == 2)
    {
        cout << "Normal:";
    }
    else
        cout << "Overweight";
}