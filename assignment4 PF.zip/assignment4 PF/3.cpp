#include <iostream>
using namespace std;
int factoiral(int num);
void whatIsProgram();

int main()
{
    whatIsProgram();
    char user = ' ';
    int num = 0;
    do
    {
        cout << "ENTER A NUMBER YOU WANT TO FACTORIAL : ";
        cin >> num;

        factoiral(num);
        cout << "-----------------------------------------------------------------------------\n";
        cout << "Factorial of " << num << " number is : " << factoiral(num);
        cout << endl;
        cout << "-----------------------------------------------------------------------------\n";
        cout << " YOU WANT TO PRINT FACTORIAL AGAIN \n IF YOU WANT TO PRINT PRESS Y \n IF YOU WANT TO NO PRINT PRESS N  ";
        cout << endl;
        cout << "-----------------------------------------------------------------------------\n";
        cout << "choice y/n :";
        cin >> user;
        cout << "----- ------------------------------------------------------------------------\n";
    } while (user != 'n');
    cout << "PROGRAMME IS OVER !!!!!";
    return 0;
}
int factoiral(int num)
{
    int factorial = 1;
    if (num < 0)
        return -1;
    else if (num == 0)
        factorial = 1;
    else
    {
        for (int i = 1; i <= num; ++i)
        {
            factorial *= i;
        }
    }
    return factorial;
}
void whatIsProgram()
{
    cout << "----------------------------------------------------------------------------\n";
    cout << "\t\tFACTORIAL OF NUMBER  \n";
    cout << "----------------------------------------------------------------------------\n";
}