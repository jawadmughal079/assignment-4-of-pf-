#include <iostream>
#include <cmath>
using namespace std;
void TriCompute(float l1, float l2, float l3, float &area, float &semiperimeter);
int main()
{
    float l1 = 0;
    float l2 = 0;
    float l3 = 0;
    float area = 0.0;
    float semiperimeter = 0.0;
    cout << "enter a lenght 1 : ";
    cin >> l1;
    cout << "enter a lenght 2 : ";
    cin >> l2;
    cout << "enter a lenght 3 : ";
    cin >> l3;
    TriCompute(l1, l2, l3, area, semiperimeter);
    cout << " semiperimeter      ;  " << semiperimeter;
    cout << endl;
    cout << " area                : " << area;
    cout << endl;
    return 0;
}
void TriCompute(float l1, float l2, float l3, float &area, float &s)
{
    s = (l1 + l2 + l3) / 2;

    area = sqrt(s * (s - l1) * (s - l2) * (s - l3));
}