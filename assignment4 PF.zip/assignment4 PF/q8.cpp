#include <iostream>
using namespace std;

int input(float &weight);
void calculating(float weight, int returnValue, float &kg, float &gram, float &ouchOrPound);
void output(float weight, int returnValue, float &kg, float &gram, float &ouchOrPound);

int main()
{

    int user = 0;
    cout << "----------------------------------------------------------------------------------\n";
    cout << "weight in pounds and ounces and will output the equivalent weight in kilograms and grams.\n ";
    cout << "----------------------------------------------------------------------------------\n";
    do
    {
        int returnValue = 0;
        float kg = 0, gram = 0, ouchOrPound = 0;
        float weight = 0;
        input(weight);
        returnValue = input(weight);
        calculating(weight, returnValue, kg, gram, ouchOrPound);
        output(weight, returnValue, kg, gram, ouchOrPound);
        cout << endl;
        cout << "  you want to exit program press 0 else to continue press any key ";
        cin >> user;
    } while (user != 0);

    return 0;
}
int input(float &weight)
{

    int select = 0;
    cout << "if you want to convert weight from pound  to kg,g,ounces press1 \nif you want to convert weight from ounces  to kg,g,pound press2\n";
    cin >> select;
    if (select == 1)
    {
        cout << " weight(pound) : ";
        cin >> weight;
        return 1;
    }
    else if (select == 2)
    {
        cout << " weight(ounces) : ";
        cin >> weight;
        return 2;
    }
}
void calculating(float weight, int returnValue, float &kg, float &gram, float &ouchOrPound)
{
    if (returnValue == 1)
    {
        kg = weight / 2.205;
        gram = weight * 454;
        ouchOrPound = weight * 16;
    }
    else
    {
        kg = weight / 35.274;
        gram = weight * 28.35;
        ouchOrPound = weight / 16;
    }
}
void output(float weight, int returnValue, float &kg, float &gram, float &ouchOrPound)
{
    if (returnValue == 1)
    {
        cout << "Pound :" << weight << "  TO  "
             << "Kg :" << kg;
        cout << endl;
        cout << "Pound :" << weight << "  TO  "
             << "gram :" << gram;
        cout << endl;
        cout << "Pound :" << weight << "  TO  "
             << "ounces :" << ouchOrPound;
    }

    else
    {
        cout << "ounces :" << weight << "  TO  "
             << "Kg :" << kg;
        cout << endl;
        cout << "ounces :" << weight << "  TO  "
             << "gram :" << gram;
        cout << endl;
        cout << "ounces :" << weight << "  TO  "
             << "Pound :" << ouchOrPound;
    }
}