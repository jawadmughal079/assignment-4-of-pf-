#include <iostream>
using namespace std;
void whatIsProgram();
double gravitionalForce(float, float, float);
void centiMeterConverter(float &distance);
int main()
{
    float mass1, mass2;
    float distance;
    char user = ' ';
    whatIsProgram();
    do
    {
        cout << "ENTER A MASS 1 : ";
        cin >> mass1;
        cout << "ENTER A MASS 1 : ";
        cin >> mass2;
        cout << "ENTER A DISTANCE INTO CENTIMETER : ";
        cin >> distance;

        centiMeterConverter(distance);
        gravitionalForce(mass1, mass2, distance);
        cout << "GRAVITIONAL FORCE IS EQUAL TO : " << gravitionalForce(mass1, mass2, distance) << " N ";
        cout << endl;
        cout << "-----------------------------------------------------------------------------\n";
        cout << " YOU WANT TO PRINT gravitionalForce AGAIN \n IF YOU WANT TO PRINT PRESS Y \n IF YOU WANT TO NO PRINT PRESS N  ";
        cout << endl;
        cout << "-----------------------------------------------------------------------------\n";
        cout << "choice y/n :";
        cin >> user;
        cout << "----- ------------------------------------------------------------------------\n";
    } while (user != 'n');
    cout << "PROGRAMME IS OVER !!!!!";
    return 0;
}
void whatIsProgram()
{
    cout << "----------------------------------------------------------------------------\n";
    cout << "\t\tgravitational attractive force between two bodies  \n";
    cout << "----------------------------------------------------------------------------\n";
}
double gravitionalForce(float m1, float m2, float dis)
{
    float gravitionalForceCalulate = 0;
    // g is equal to 6.67*10^-8
    // 10^-8 equal to 0.00000001
    // so g is equal to 0.0000000667
    double g = 0.0000000667;
    float force = g * m1 * m2 / (dis * dis);
    return force;
}
void centiMeterConverter(float &distance)
{
    int temp = distance;
    int div = 1;
    int counter = 0;
    while (temp != 0)
    {
        div %= temp;
        temp /= 10;
        counter++;
    }
    distance / counter;
}