#include <iostream>
#include <math.h> // this is use for power
using namespace std;
void whatIsProgram();
int main()
{
    whatIsProgram();
    float speed = 0.0;
    float temperature = 0.0;
    int windChillIndex = 0; // chill index values always round off
    // W = 13.12 + 0.6215 T − 11.37 (V0.16) + 0.2965 T (V0.16)
    // speed = wind speed in m/sec
    //temperature = temperature in degrees Celsius: t <= 10
    //W = wind chill index (in degrees Celsius)
    cout << "ENTER A SPEED IN m/sec :  ";
    cin >> speed;
    cout << "ENTER A TEMPERATURE IN CELSIUS :  ";
    cin >> temperature;
    while (temperature > 10)
    {
        cout << "ENTER A TEMPERATURE AGAIN : ";
        cin >> temperature;
    }
    windChillIndex = 13.12 + 0.6215 * temperature - 11.37 * pow(speed, 0.16) + 0.2965 * temperature * pow(speed, 0.16);
    cout << "WindChillIndex  in celsius : " << windChillIndex;
    return 0;
}
void whatIsProgram()
{
    cout << "----------------------------------------------------------------------------\n";
    cout << "\t\twind chill index . \n";
    cout << "----------------------------------------------------------------------------\n";
}