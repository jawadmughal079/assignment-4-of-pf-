// #include <iostream>
// using namespace std;
// float totalBills(int totalTime, float prize);
// int main()
// {
//     cout << " --------------------------------------------------------------------------\n";
//     cout << "\t\t\tWELCOME TO PARKING GARAGE :\n ";
//     cout << " --------------------------------------------------------------------------\n";
//     float charge = 0;
//     int coutomerId;
//     int startingTime;
//     int outTime;
//     float totalBill = 0;
//     float totalBillYesterDay = 0;
//     int c = 0;
//     do
//     {
//         cout << "Enter a coutomer id : ";
//         cin >> coutomerId;
//         cout << "Enter a starting time  : ";
//         cin >> startingTime;
//         cout << "Enter a out time when car leave the garage : ";
//         cin >> outTime;
//         int totalTime = 0;
//         totalTime = outTime - startingTime;
//         if (totalTime <= 3)
//         {
//             charge = 3;
//             totalBills(totalTime, charge);
//             cout << "Total time of customer is : " << totalTime << endl;
//             cout << "total bill of customer is : " << totalBills(totalTime, charge);
//         }
//         else if (totalTime >= 3)
//         {
//             charge = .5;

//             totalTime = totalTime - 3;
//             totalBills(totalTime, charge);
//             if (totalBill >= 10)
//             {
//                 cout << "Total time of customer is : " << totalTime + 3 << endl;
//                 cout << "total bill of customer is : 10 $";
//                 cout << endl;
//             }
//             if (totalBill < 10)
//             {
//                 cout << "coutomer id : ";
//                 cout << coutomerId;
//                 cout << endl;
//                 cout << "Total time of customer is : " << totalTime + 3;

//                 cout << "total bill of customer is : " << totalBills(totalTime, charge) + 3;

//                 cout << "$";
//             }
//         }
//         cout << endl;
//         int add = 0;
//         add = totalBillYesterDay + totalBill + 3;
//         cout << "running total of yesterday receipts : " << add;

//     } while (c = -1);

//     return 0;
// }
// float totalBills(int totalTime, float prize)
// {

//     float totalBills = float(totalTime) * prize;

//     return totalBills;
// }
#include <iostream>
using namespace std;
void swap(int &start, int &end);
float bill(int totalTime, float price);
int main()
{

    int user = 0;
    float start = 0;
    float end = 0;
    float price = 0;
    float totalTime = 0;
    float add = 0;
    do
    {
        cout << "Enter a starting time : ";
        cin >> start;
        cout << "Enter a end time : ";
        cin >> end;
        if (end < start)
        {
            swap(start, end);
        }

        totalTime = end - start;
        if (totalTime <= 3)
        {
            cout << " Total time of user is : " << totalTime;
            cout << endl;
            totalTime = 1;
            price = 3;
            bill(totalTime, price);
            cout << "Total Bill of user is : " << bill(totalTime, price);
            add += bill(totalTime, price);
            cout << endl;
        }
        else
        {
            totalTime = totalTime - 3;
            price = 0.5;
            float totalBill = bill(totalTime, price);
            if (totalBill >= 10)
            {
                cout << "Total time of customer is : " << totalTime + 3;
                cout << endl;
                cout << " Total Bill Of customer is :  10 $ ";
                add = add + 10.0;
            }
            else
            {
                if (totalBill <= 7)
                {
                    cout << "Total time of customer is : " << totalTime + 3;
                    cout << endl;
                    cout << " Total Bill Of customer is :  10 sadf ";

                    add = add + bill(totalTime, price);
                    add = add + 3.0;
                }
                else
                {
                    cout << "Total time of customer is : " << totalTime + 3;
                    cout << endl;
                    cout << " Total Bill Of customer is :  10  ";
                    add += 10;
                }
            }
        }
        cout << " YESTER DAY EARNING IS : " << add;
        cout << endl;
        cout << " You want to  exit press -1";
        cin >> user;
    } while (user != -1);

    return 0;
}
void swap(int &start, int &end)
{
    int temp = end;
    end = start;
    start = temp;
}
float bill(int totalTime, float price)
{
    float bill1 = totalTime * price;
    return bill1;
}