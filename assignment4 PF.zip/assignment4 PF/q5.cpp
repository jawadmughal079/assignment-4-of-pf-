// #include <iostream>
// using namespace std;
// void isData(int &Data, int maxDays);
// int maxData(int Data, int Month, int monthDates[], int Size);
// void isMonth(int &Month);
// void isYear(int Year);
// int main()
// {
//     const int Size = 13;
//     int year = 0;
//     int Month = 0;
//     int Data = 0;
//     int monthDates[Size] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31, 0};
//     cout << "Enter a Month : ";
//     cin >> Month;
//     isMonth(Month);
//     maxData(Data, Month, monthDates, Size);
//     int maxDays = 0;
//     maxDays = maxData(Data, Month, monthDates, Size);
//     cout << "Max days in month is " << maxDays;
//     cout << endl;
//     cout << "Enter a Data : ";
//     cin >> Data;
//     isData(Data, maxDays);
//     cout << endl;
//     cout << "Enter a year : ";
//     cin >> year;
//     isYear(year);
//     return 0;
// }
// void isMonth(int &Month)
// {
//     while (Month < 1 || Month > 12)
//     {
//         cout << "Enter a month again : ";
//         cin >> Month;
//     }
// }
// int maxData(int Data, int Month, int monthDates[], int size)
// {
//     for (int i = 0; i < size; i++)
//     {
//         if (i == Month)
//         {

//             return monthDates[i - 1];
//         }
//     }
// }
// void isData(int &Data, int maxDays)
// {
//     while (Data < 1 || Data > maxDays)
//     {
//         cout << "Enter a Data again : ";
//         cin >> Data;
//     }
// }
// void isYear(int Year)
// {
//     if (Year % 4 == 0 && Year % 4 != 0 || Year % 400 == 0)
//     {
//         cout << " this is loop year \n 366 days in year\n";
//         cout << "31/12/" << Year;
//     }
//     else
//     {
//         cout << " this is not loop year \n 365 days in year\n";
//         cout << "31/12/" << Year;
//     }
// }
#include <iostream>
using namespace std;
void calculate()
{
    int input, answer, first, second;
    first = rand() % 30 + 1;
    second = rand() % 30 + 1;
    cout << "What is " << first << " "
         << "Times"
         << " " << second << " :";
    cin >> answer;
    if (answer == first * second)
    {
        cout << "You are doing great" << endl;
    }
    else if (answer != first * second)
    {
        cout << "Your answer is wrong Try again:" << endl;
    }
}

int main()
{

    int input;
    while (input != -1)
    {
        calculate();
        cout << "Press -1 to terminate:";
        cin >> input;
        if (input == -1)
        {
            cout << "That's all for now. Bye.";
        }
    }
    return 0;
}