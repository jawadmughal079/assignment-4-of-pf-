#include <iostream>
using namespace std;
void whatIsProgram();
void derivative(float array[], float avgForStandar, int size);
void input(float array[], const int size);
void output(float array[], const int size);
float avg(float array[], const int size);
float sqrt(int num);
int main()
{
    whatIsProgram();
    const int SIZE = 4;
    float array[SIZE];
    float avgForStandar;
    char terminal = ' ';
    do
    {
        input(array, SIZE);
        output(array, SIZE);
        avgForStandar = avg(array, SIZE);
        cout << endl;
        cout << "TOTAL AVG OF NUMBER IS  : " << avgForStandar << endl;
        cout << endl;
        derivative(array, avgForStandar, SIZE);
        cout << "IF YOU WANT TO AGAIN RUN THE PROGRAME PRESS  Y \n IF YOU WANT TO EXIT THE PROGRAMME PRESS N  : ";
        cin >> terminal;
    } while (terminal != 'n');
    cout << endl;
    cout << " YOUR PROGRAM IS END";
    cout << endl;
    return 0;
}
void whatIsProgram()
{
    cout << "----------------------------------------------------------------------------\n";
    cout << "\t\taverage and standard deviation of four scores. \n";
    cout << "----------------------------------------------------------------------------\n";
}
void input(float array[], const int size)
{
    for (int i = 0; i < size; i++)
    {
        cout << "Enter a " << i + 1 << " value: ";
        cin >> array[i];
    }
}
void output(float array[], const int size)
{
    for (int i = 0; i < size; i++)
    {
        cout << "ENTER : " << i + 1 << " NUMBER EQUAL TO : ";
        cout << array[i];
        cout << endl;
    }
}
float avg(float array[], const int size)
{
    int sum = 0;
    float avg = 0.0;
    for (int i = 0; i < size; i++)
    {
        sum += array[i];
    }
    avg = sum / float(size);
    return avg;
}
void derivative(float array[], float avgForStandar, int size)
{
    float der = 0;
    float temp = 0;
    float sqaureRootOfstanderd = 0.0;
    for (int i = 0; i < size; i++)
    {
        temp = (array[i] - avgForStandar);
        temp *= temp;
        der += temp;
    }
    sqrt(der);
    sqrt(size);
    cout << endl;
    cout << "STANDARD DERIVATION OF NUMBER IS : " << sqrt(der) / sqrt(size) << endl;

    cout << endl;
}
float sqrt(int num)
{
    float sqrt = num / 2;
    float temp = 0;
    while (sqrt != temp)
    {
        temp = sqrt;
        sqrt = (num / temp + temp) / 2;
    }
    return sqrt;
}